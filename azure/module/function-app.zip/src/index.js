"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const functions_1 = require("@azure/functions");
const api_1 = require("@mcma/api");
// import { CosmosDbTableProvider, fillOptionsFromConfigVariables } from "@mcma/azure-cosmos-db";
// import { AppInsightsLoggerProvider } from "@mcma/azure-logger";
// import { AzureFunctionApiController } from "@mcma/azure-functions-api";
// import { JobProfile, Service } from "@mcma/core";
// import { AzureKeyVaultSecretsProvider } from "@mcma/azure-key-vault";
const azure_function_api_controller_1 = require("./azure-function-api-controller");
const core_1 = require("@mcma/core");
// const loggerProvider = new AppInsightsLoggerProvider("service-registry-api-handler");
const loggerProvider = new core_1.ConsoleLoggerProvider("service-registry-api-handler");
// const dbTableProvider = new CosmosDbTableProvider(fillOptionsFromConfigVariables());
// const secretsProvider = new AzureKeyVaultSecretsProvider();
// const securityMiddleware = new McmaApiKeySecurityMiddleware({ secretsProvider });
// //
// const restController =
//     new AzureFunctionApiController(
//         {
//             routes: new McmaApiRouteCollection()
//                 .addRoutes(new DefaultRouteCollection(dbTableProvider, Service))
//                 .addRoutes(new DefaultRouteCollection(dbTableProvider, JobProfile)),
//             loggerProvider,
//             middleware: [securityMiddleware],
//         });
const restController2 = new azure_function_api_controller_1.AzureFunctionApiController({
    routes: new api_1.McmaApiRouteCollection(),
    loggerProvider
});
async function handler(request, context) {
    context.log(`Http function processed request for url "${request.url}"`);
    const logger = await loggerProvider.get(context.invocationId);
    try {
        logger.functionStart(context.invocationId);
        logger.debug(context);
        logger.debug(request);
        // await restController2.handleRequest(request);
    }
    catch (e) {
        context.error(e);
    }
    finally {
        logger.functionEnd(context.invocationId);
        // loggerProvider.flush();
    }
    return {
        status: 200,
        jsonBody: { "Hello": "world 3!" }
    };
}
functions_1.app.http("api-handler", {
    route: "{*path}",
    methods: ["GET", "HEAD", "POST", "PUT", "DELETE", "OPTIONS", "PATCH", "TRACE", "CONNECT"],
    authLevel: "anonymous",
    handler
});
