"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const functions_1 = require("@azure/functions");
const api_1 = require("@mcma/api");
const core_1 = require("@mcma/core");
const azure_cosmos_db_1 = require("@mcma/azure-cosmos-db");
const azure_key_vault_1 = require("@mcma/azure-key-vault");
const azure_logger_1 = require("@mcma/azure-logger");
const azure_functions_api_1 = require("@mcma/azure-functions-api");
const dbTableProvider = new azure_cosmos_db_1.CosmosDbTableProvider((0, azure_cosmos_db_1.fillOptionsFromConfigVariables)());
const loggerProvider = new azure_logger_1.AppInsightsLoggerProvider("service-registry-api-handler");
const secretsProvider = new azure_key_vault_1.AzureKeyVaultSecretsProvider();
const securityMiddleware = new api_1.McmaApiKeySecurityMiddleware({ secretsProvider });
const restController = new azure_functions_api_1.AzureFunctionApiController({
    routes: new api_1.McmaApiRouteCollection()
        .addRoutes(new api_1.DefaultRouteCollection(dbTableProvider, core_1.Service))
        .addRoutes(new api_1.DefaultRouteCollection(dbTableProvider, core_1.JobProfile)),
    loggerProvider,
    middleware: [securityMiddleware],
});
async function handler(request, context) {
    const logger = await loggerProvider.get(context.invocationId);
    try {
        logger.functionStart(context.invocationId);
        logger.debug(request);
        logger.debug(context);
        return await restController.handleRequest(request);
    }
    finally {
        logger.functionEnd(context.invocationId);
        loggerProvider.flush();
    }
}
functions_1.app.http("api-handler", {
    route: "{*path}",
    methods: ["GET", "HEAD", "POST", "PUT", "DELETE", "OPTIONS", "PATCH", "TRACE", "CONNECT"],
    authLevel: "anonymous",
    handler
});
