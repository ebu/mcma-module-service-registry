"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const aws_xray_sdk_core_1 = require("aws-xray-sdk-core");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const client_secrets_manager_1 = require("@aws-sdk/client-secrets-manager");
const core_1 = require("@mcma/core");
const api_1 = require("@mcma/api");
const aws_dynamodb_1 = require("@mcma/aws-dynamodb");
const aws_api_gateway_1 = require("@mcma/aws-api-gateway");
const aws_secrets_manager_1 = require("@mcma/aws-secrets-manager");
const dynamoDBClient = (0, aws_xray_sdk_core_1.captureAWSv3Client)(new client_dynamodb_1.DynamoDBClient({}));
const secretsManagerClient = (0, aws_xray_sdk_core_1.captureAWSv3Client)(new client_secrets_manager_1.SecretsManagerClient({}));
const loggerProvider = new core_1.ConsoleLoggerProvider("service-registry-api-handler");
const dbTableProvider = new aws_dynamodb_1.DynamoDbTableProvider({}, dynamoDBClient);
const middleware = [];
if (process.env.MCMA_API_KEY_SECURITY_CONFIG_SECRET_ID) {
    const secretsProvider = new aws_secrets_manager_1.AwsSecretsManagerSecretsProvider({ client: secretsManagerClient });
    const securityMiddleware = new api_1.McmaApiKeySecurityMiddleware({ secretsProvider });
    middleware.push(securityMiddleware);
}
const restController = new aws_api_gateway_1.ApiGatewayApiController({
    routes: new api_1.McmaApiRouteCollection()
        .addRoutes(new api_1.DefaultRouteCollection(dbTableProvider, core_1.Service))
        .addRoutes(new api_1.DefaultRouteCollection(dbTableProvider, core_1.JobProfile)),
    loggerProvider,
    middleware,
});
async function handler(event, context) {
    const logger = await loggerProvider.get(context.awsRequestId);
    try {
        logger.functionStart(context.awsRequestId);
        logger.debug(event);
        logger.debug(context);
        return await restController.handleRequest(event, context);
    }
    catch (error) {
        logger.error(error);
        throw error;
    }
    finally {
        logger.functionEnd(context.awsRequestId);
    }
}
