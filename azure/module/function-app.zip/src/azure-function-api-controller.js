"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AzureFunctionApiController = void 0;
const url_1 = require("url");
const fs = require("fs");
const uuid_1 = require("uuid");
const core_1 = require("@mcma/core");
const api_1 = require("@mcma/api");
const fetch_1 = require("undici/types/fetch");
function getPath(req) {
    const hostJson = JSON.parse(fs.readFileSync("host.json", "utf-8"));
    let routePrefix = (hostJson?.extensions?.http?.routePrefix) ?? "api";
    if (routePrefix.length) {
        if (routePrefix[0] !== "/") {
            routePrefix = "/" + routePrefix;
        }
        if (routePrefix[routePrefix.length - 1] === "/") {
            routePrefix = routePrefix.subtr(0, routePrefix.length - 1);
        }
    }
    const requestUrl = new url_1.URL(req.url);
    if (!requestUrl.pathname.startsWith(routePrefix)) {
        throw new core_1.McmaException(`Received request for url ${req.url} with unexpected path ${requestUrl.pathname}. Expected path to be prefixed with ${routePrefix}`);
    }
    return requestUrl.pathname.substring(routePrefix.length);
}
class AzureFunctionApiController {
    loggerProvider;
    configVariables;
    apiController;
    config;
    constructor(routesOrConfig, loggerProvider, configVariables) {
        this.loggerProvider = loggerProvider;
        this.configVariables = configVariables;
        if (routesOrConfig instanceof api_1.McmaApiRouteCollection) {
            this.config = {
                routes: routesOrConfig,
                loggerProvider: loggerProvider,
                configVariables: configVariables,
            };
        }
        else {
            this.config = routesOrConfig;
        }
        if (!this.config.configVariables) {
            this.config.configVariables = core_1.ConfigVariables.getInstance();
        }
        this.apiController = new api_1.McmaApiController(this.config.routes, this.config.middleware);
    }
    async handleRequest(req) {
        const headers = {};
        for (const entry of req.headers.entries()) {
            headers[entry[0]] = entry[1];
        }
        const queryStringParameters = {};
        for (const entry of req.query.entries()) {
            queryStringParameters[entry[0]] = entry[1];
        }
        const requestContext = new api_1.McmaApiRequestContext(new api_1.McmaApiRequest({
            id: (0, uuid_1.v4)(),
            path: getPath(req),
            httpMethod: req.method,
            headers,
            pathVariables: {},
            queryStringParameters,
            body: req.body
        }), this.config.loggerProvider, this.config.configVariables);
        await this.apiController.handleRequest(requestContext);
        const responseHeaders = new fetch_1.Headers();
        for (const header of Object.keys(requestContext.response.headers)) {
            responseHeaders.append(header, requestContext.response.headers[header]);
        }
        return {
            status: requestContext.response.statusCode,
            headers: responseHeaders,
            body: requestContext.response.body
        };
    }
}
exports.AzureFunctionApiController = AzureFunctionApiController;
